<!--
     Name: Dejanae Shirley
     File Name: process.php
     Date: August 11,2023
     Description: 
-->

<!DOCTYPE html>
<html>

<head lang="en">
     <meta charset="utf-8">
     <title>Form Data - Processed</title>
     <link rel="stylesheet" href="css/styles.css" />
</head>

<body>

     <?php
     include 'headerM.php';
     ?>
     <?php
     // Check if form data has been submitted
     if ($_SERVER["REQUEST_METHOD"] == "POST") {
          // Retrieve form data using the $_POST superglobal array
          $title = $_POST["title"];
          $description = $_POST["description"];
          $genre = $_POST["genre"];
          $subject = $_POST["subject"];
          $star = $_POST["Star"];
          $year = $_POST["year"];
          $production = $_POST["Production"];

          // Display the form data
          echo "<p><strong>Movie Information Saved</strong></p>";
          echo '<hr>';
          echo "<p><strong>Title:</strong> $title</p>";
          echo "<p><strong>Description:</strong> $description</p>";
          echo "<p><strong>Genre:</strong> $genre</p>";
          echo "<p><strong>Subject:</strong> $subject</p>";
          echo "<p><strong>Star:</strong> $star</p>";
          echo "<p><strong>Year:</strong> $year</p>";
          echo "<p><strong>Production:</strong> $production</p>";
     } else {
          // If the form is not submitted, display a message
          echo "<p>No form data submitted.</p>";
     }
     ?>
</body>
<?php
include 'footerM.php';
?>
</html>