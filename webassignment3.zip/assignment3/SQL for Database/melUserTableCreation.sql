  

-- Course name: Web Programming (CST_8285_310)
-- Professor:Alem Legesse
-- Assignment 2
-- Due Date: August 7 2023
-- Group 3
-- Students: Ali Aydogan,  Aira Nicole De Castro,  Larysa Champagne, Dejanae Shirley. 


CREATE DATABASE IF NOT EXISTS webassign2;


-- Creating a table for the admin page (Aira)
CREATE TABLE IF NOT EXISTS webassign2.users (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, password VARCHAR(45) NOT NULL, username VARCHAR(45) NOT NULL UNIQUE, firstName VARCHAR(45) NOT NULL, 
                    lastName VARCHAR(50) NOT NULL, email VARCHAR(45) NOT NULL UNIQUE, phone VARCHAR(20) NULL, role VARCHAR(15) NULL);


INSERT INTO webassign2.users (username, password, firstName, lastName, email, phone, role)
VALUES
('aira0023', 'aira0023','Aira', 'Nicole', 'aira0023@algonquinlive.com', '6130000010', 'admin'),
('DJ', 'password', 'Dejanae', 'Shirley', 'dj.shirley@gmail.com', '', ''),
('Lora', 'password', 'Larysa', 'Champagne', 'larysa.champ@hotmail.com', '613000000',''),
('testUser1', 'test', 'test', 'user', 'test.user@mail.ca', '', 'admin');



-- Creating a table for the menu page (Larysa Champagne)
CREATE TABLE webassign2.items (id INT PRIMARY KEY NOT NULL AUTO_INCREMENT, image VARCHAR(250) NULL, name VARCHAR(250) NULL, category VARCHAR(250) NULL, description VARCHAR(400) NULL, price VARCHAR(250) NULL);

-- Inserting values into items table
INSERT INTO webassign2.items (image, name, category, description, size, price)
VALUES
('./images/blackforest.jpg', 'Black Forest', 'Cake', ' A German classic combining layers of chocolate sponge cake, whipped cream, and cherries, finished with chocolate shavings.','Medium','$7.50'),
('./images/velvet.jpg', 'Red Velvet Cake.', 'Cake', 'A striking red-hued cake with a subtle cocoa flavor, complemented by a velvety cream cheese frosting.', 'Medium','$7.55'),
('./images/Tiramisu.jpg', 'Tiramisu', 'Cake', 'A heavenly Italian dessert in cake form, featuring layers of coffee-soaked sponge and mascarpone cheese filling dusted with cocoa powder.', 'Medium', '$6.50'),
('./images/strawberry.jpg', 'Strawberry Shortcake', 'Cake', ' A German classic combining layers of chocolate sponge cake, whipped cream, and cherries, finished with chocolate shavings.', 'Medium','$8.55'),
('./images/hummingbird.jpg', 'Hummingbird', 'Cake', 'A Southern favorite boasting a blend of banana, pineapple, and pecans, frosted with cream cheese icing..', 'Medium', '$7.55'),
('./images/lemon.jpg', 'Lemon Drizzle Cake', 'Cake', 'A zesty delight with a moist lemon-infused sponge, topped with a tangy lemon syrup for an extra burst of flavor.', 'Medium','$4.55'),


('./images/caramel.jpg', 'Caramel Macchiato', 'Drink', 'A velvety espresso topped with steamed milk and a luscious swirl of caramel, delivering a delightful balance of sweet and bold flavors', 'Medium', '$11.55'),
('./images/affogato.jpg', 'Affogato', 'Drink', ' A simple yet indulgent dessert-like treat that combines a shot of hot espresso poured over a scoop of creamy vanilla ice cream.', 'Medium','$10.55'),
('./images/frappuccino.jpg', 'Mocha Frappuccino', 'Drink', 'A delightful icy blend of espresso, milk, chocolate syrup, and ice, offering a refreshing and decadent pick-me-up on warm days.', 'Medium','$11.55'),
('./images/caramel.jpg', 'Irish Coffee', 'Drink', 'A classic combination of hot coffee, Irish whiskey, brown sugar, and topped with whipped cream, creating a warming and spirited concoction.', 'Medium','$9.55'),
('./images/cortado.jpg', 'Cortado', 'Drink', ' An equal parts mixture of espresso and steamed milk, resulting in a bold yet balanced beverage that highlights the espresso natural flavors.','Medium','$10.55'),
 
('./images/chai.jpg', 'Dirty Chai Latte', 'Drink', 'A spiced twist on the traditional latte, blending espresso, steamed milk, and chai tea for a robust and aromatic delight.', 'Medium', '$8.55'),
('./images/americano.jpg', 'Americano', 'Drink', 'A simple yet satisfying coffee made by diluting a shot of espresso with hot water, offering a milder flavor while retaining the essence of espresso.', 'Medium','$6.55'),
('./images/espresso.jpg', 'Espresso', 'Drink', 'Concentrated and intense shot of coffee brewed by forcing hot water through finely-ground coffee beans, delivering a bold and rich flavor in a small serving..', 'Medium', '$6.55'),
('./images/capuccino.jpg', 'Capuccino', 'Drink', 'A classic Italian coffee consisting of equal parts espresso, steamed milk, and frothed milk, resulting in a creamy and velvety cup with a dusting of cocoa or cinnamon on top.', 'Medium', '$6.55');
