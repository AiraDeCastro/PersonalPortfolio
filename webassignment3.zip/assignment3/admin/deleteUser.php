<!-- Course name: Web Programming (CST_8285_310)
Due Date: August 7 2023
Professor:Alem Legesse
Assignment 2
Group 3
Students: Ali Aydogan,  Aira Nicole De Castro,  Larysa Champagne, Dejanae Shirley-->

<!-- This php file deletes the row from the user table that is assosicated with the id sent through GET method from the userManage page -->

<?php

$servername = "localhost";
$user = "root";
$databasePasswd = "";
$database = "webassign2";

$id = $_GET["id"];

//Create connection
$connection = new mysqli($servername, $user, $databasePasswd, $database,3308);

$result = $connection -> query("DELETE FROM users WHERE id='$id'");
if (!$result) {
    $errorMessage = "Invalid Query: " . $connection -> error;
}

header("location: ./userManage.php");
?>