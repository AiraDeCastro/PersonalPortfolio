<!-- Course name: Web Programming (CST_8285_310)
Due Date: August 7 2023
Professor:Alem Legesse
Assignment 2
Group 3
Students: Ali Aydogan,  Aira Nicole De Castro,  Larysa Champagne, Dejanae Shirley-->

<?php
// super global variables
$userid     =$_POST['userid'];
$password   =$_POST['password'];
$fname      =$_POST['fname'];
$lname      =$_POST['lname'];
$email      =$_POST['email'];
$phone      =$_POST['phone'];

// Database connection
$conn = new mysqli('localhost','root','','webassign2', 3308);

if ($conn->connect_error) {
    die('Connection Failed : '.$conn->connect_error);
} 
else {
    // insert user details into database
    $stmt =$conn->prepare("INSERT INTO users (username, password,firstname, lastname,email, phone) 
    VALUES (?,?,?,?,?,?)");
    $stmt->bind_param("ssssss",$userid,$password,$fname,$lname,$email,$phone);
    $stmt->execute();    
    header("Location:index.html");
    
    //close connection and statement
    $stmt->close();
    $conn->close();
}
?>