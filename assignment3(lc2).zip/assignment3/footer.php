<!-- Course name: Web Programming (CST_8285_310)
Due Date: August 7 2023
Professor:Alem Legesse
Assignment 2
Group 3
Students: Ali Aydogan,  Aira Nicole De Castro,  Larysa Champagne, Dejanae Shirley-->
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="HandheldFriendly" content="true">
  <meta name="author" content="Group 3">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="css/assignment2.css" rel="stylesheet" type="text/css">
</head>
<body>
<div class="footer">
  <p>© 2023 My Coffee Shop (mycoffee.com). All Rights Reserved.</p>
</div>
</body>
</html>